<?php
session_start();
$title = "Terms Of Use";
require 'config/config.php';
include 'templates/header.phtml';
include 'templates/terms-of-use.phtml';