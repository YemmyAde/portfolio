<?php
session_start();
$title = "Privacy";
require 'config/config.php';
include 'templates/header.phtml';
include 'templates/privacy.phtml';